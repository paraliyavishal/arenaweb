import React from 'react';

function YourPrice() {
  return (
    <div>
      
    </div>
  );
}

export default YourPrice;
