import React from 'react';



function Journey() {
  return (
    <div>
      
    </div>
  );
}

export default Journey;
