import React from 'react';

function BlogsAndNews() {
  return (
    <div>
    
    </div>
  );
}

export default BlogsAndNews;
