import React from 'react';

function Games() {
  return (
    <div>
      
    </div>
  );
}

export default Games;
