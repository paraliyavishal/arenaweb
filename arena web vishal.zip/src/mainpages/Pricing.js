import React from 'react';

function Pricing() {
  return (
    <div>
      
    </div>
  );
}

export default Pricing;
